export const createSuccess = (message, data) => {
    return {
        success: "success",
        message,
        data
    };
}